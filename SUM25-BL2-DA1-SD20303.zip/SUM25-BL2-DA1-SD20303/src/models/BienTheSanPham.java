/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.math.BigDecimal;

/**
 *
 * @author VIET DUC
 */
// class này vừa ánh xạ vừa trung gian luôn nhé :3
public class BienTheSanPham {

    private int id;
    private int sanpham_id;
    private int mausac_id;
    private int kichthuoc_id;
    private int soLuong;

        // Các trường mở rộng lấy từ join với bảng khác
    private String tenSanPham;
    private String mauSac;
    private String kichThuoc;
    private BigDecimal giaBan;

    public BienTheSanPham() {
    }

    public BienTheSanPham(int id, int sanpham_id, int mausac_id, int kichthuoc_id, int soLuong) {
        this.id = id;
        this.sanpham_id = sanpham_id;
        this.mausac_id = mausac_id;
        this.kichthuoc_id = kichthuoc_id;
        this.soLuong = soLuong;
    }

    public BienTheSanPham(int sanpham_id, int mausac_id, int kichthuoc_id, int soLuong) {
        this.sanpham_id = sanpham_id;
        this.mausac_id = mausac_id;
        this.kichthuoc_id = kichthuoc_id;
        this.soLuong = soLuong;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSanpham_id() {
        return sanpham_id;
    }

    public void setSanpham_id(int sanpham_id) {
        this.sanpham_id = sanpham_id;
    }

    public int getMausac_id() {
        return mausac_id;
    }

    public void setMausac_id(int mausac_id) {
        this.mausac_id = mausac_id;
    }

    public int getKichthuoc_id() {
        return kichthuoc_id;
    }

    public void setKichthuoc_id(int kichthuoc_id) {
        this.kichthuoc_id = kichthuoc_id;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public String getMauSac() {
        return mauSac;
    }

    public void setMauSac(String mauSac) {
        this.mauSac = mauSac;
    }

    public String getKichThuoc() {
        return kichThuoc;
    }

    public void setKichThuoc(String kichThuoc) {
        this.kichThuoc = kichThuoc;
    }

    public BigDecimal getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(BigDecimal giaBan) {
        this.giaBan = giaBan;
    }

    
}
