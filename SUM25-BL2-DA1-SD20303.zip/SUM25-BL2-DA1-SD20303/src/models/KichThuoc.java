/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author VIET DUC
 */
public class KichThuoc {

    private int id;
    private int ten;

    public KichThuoc() {
    }

    public KichThuoc(int id, int ten) {
        this.id = id;
        this.ten = ten;
    }

    public KichThuoc(int ten) {
        this.ten = ten;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTen() {
        return ten;
    }

    public void setTen(int ten) {
        this.ten = ten;
    }

    @Override
    public String toString() {
        return String.valueOf(ten);
    }

}
