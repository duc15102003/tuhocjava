/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.util.Date;

/**
 *
 * @author VIET DUC
 */
public class GioHang {
    private int id;
    private String maNV;
    private Date ngayTao;

    public GioHang() {
    }

    public GioHang(String maNV, Date ngayTao) {
        this.maNV = maNV;
        this.ngayTao = ngayTao;
    }

    
    public GioHang(int id, String maNV, Date ngayTao) {
        this.id = id;
        this.maNV = maNV;
        this.ngayTao = ngayTao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }
    
    
    
}
