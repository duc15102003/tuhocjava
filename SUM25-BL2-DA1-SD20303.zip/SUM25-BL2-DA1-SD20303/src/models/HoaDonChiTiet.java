/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.math.BigDecimal;

/**
 *
 * @author VIET DUC
 */
public class HoaDonChiTiet {
    private int id;
    private int ma_hd;
    private int bienthe_id;
    private int soLuong;
    private BigDecimal giaBan;

    public HoaDonChiTiet() {
    }

    public HoaDonChiTiet(int id, int ma_hd, int bienthe_id, int soLuong, BigDecimal giaBan) {
        this.id = id;
        this.ma_hd = ma_hd;
        this.bienthe_id = bienthe_id;
        this.soLuong = soLuong;
        this.giaBan = giaBan;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMa_hd() {
        return ma_hd;
    }

    public void setMa_hd(int ma_hd) {
        this.ma_hd = ma_hd;
    }

    public int getBienthe_id() {
        return bienthe_id;
    }

    public void setBienthe_id(int bienthe_id) {
        this.bienthe_id = bienthe_id;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(BigDecimal giaBan) {
        this.giaBan = giaBan;
    }

    
    
    
}
