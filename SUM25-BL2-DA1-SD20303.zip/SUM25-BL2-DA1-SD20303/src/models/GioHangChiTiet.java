/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author VIET DUC
 */
public class GioHangChiTiet {
    private int id;
    private int gioHangId;
    private int bienTheId;
    private int soLuong;

    public GioHangChiTiet() {
    }

    public GioHangChiTiet(int gioHang_id, int bienTheId, int soLuong) {
        this.gioHangId = gioHang_id;
        this.bienTheId = bienTheId;
        this.soLuong = soLuong;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGioHang_id() {
        return gioHangId;
    }

    public void setGioHang_id(int gioHang_id) {
        this.gioHangId = gioHang_id;
    }

    public int getBienthe_id() {
        return bienTheId;
    }

    public void setBienthe_id(int bienthe_id) {
        this.bienTheId = bienthe_id;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
    
    
}
