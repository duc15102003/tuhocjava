/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.util.List;
import models.BienTheSanPham;
import models.SanPham;
import models.MauSac;
import models.KichThuoc;
import service.BienTheSanPhamService;
import service.SanPhamService;
import service.MauSacService;
import service.KichThuocService;

/**
 *
 * @author VIET DUC
 */
public class QuanLySanPham extends javax.swing.JFrame {

    MauSac ms = new MauSac();
    KichThuoc kt = new KichThuoc();
    SanPhamService spService = new SanPhamService();
    MauSacService mausacService = new MauSacService();
    KichThuocService ktService = new KichThuocService();
    BienTheSanPhamService bienTheSanPhamSv = new BienTheSanPhamService();

    private int oldSanPhamId;
    private int oldMauSacId;
    private int oldKichThuocId;

    /**
     * Creates new form QuanLySanPham
     */
    public QuanLySanPham() {
        initComponents();
        this.setLocationRelativeTo(null);
        loadTableSanPham();
        loadComboBoxMauSac();
        loadComboBoxKichThuoc();
        txtid.setEditable(false);

    }

    private void loadComboBoxMauSac() {
        DefaultComboBoxModel modelMauSac = new DefaultComboBoxModel();
        List<MauSac> list = mausacService.getAllMauSac();
        for (MauSac ms : list) {
            modelMauSac.addElement(ms);
        }
        cboMauSac.setModel(modelMauSac);
    }

    private void loadComboBoxKichThuoc() {
        DefaultComboBoxModel modelKichThuoc = new DefaultComboBoxModel();
        List<KichThuoc> list = ktService.getAllKichThuoc();
        for (KichThuoc ms : list) {
            modelKichThuoc.addElement(ms);
        }
        cboSize.setModel(modelKichThuoc);
    }

    private void loadTableSanPham() {
        DefaultTableModel tblModel = new DefaultTableModel(
                new Object[]{"ID", "Tên", "Số lượng", "Màu sắc", "Kích thước", "Giá"}, 0
        );

        List<Object[]> list = spService.layDanhSachSanPhamFull();

        for (Object[] rowData : list) {
            tblModel.addRow(rowData);
        }

        tblSanPham.setModel(tblModel);
    }

    private void clearForm() {
        txtid.setText("");
        txtTenSanPham.setText("");
        txtGia.setText("");
        txtSoLuong.setText("");
        cboMauSac.setSelectedIndex(-1);
        cboSize.setSelectedIndex(-1);
        tblSanPham.clearSelection();
    }

    private boolean validateForm() {
        if (txtTenSanPham.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên sản phẩm không được để trống!");
            return false;
        }

        try {
            BigDecimal gia = new BigDecimal(txtGia.getText().trim());
            if (gia.compareTo(BigDecimal.ZERO) < 0) {
                JOptionPane.showMessageDialog(this, "Giá phải >= 0!");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Giá không hợp lệ!");
            return false;
        }

        try {
            int soLuong = Integer.parseInt(txtSoLuong.getText().trim());
            if (soLuong < 0) {
                JOptionPane.showMessageDialog(this, "Số lượng phải >= 0!");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ!");
            return false;
        }

        if (cboMauSac.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn màu sắc!");
            return false;
        }

        if (cboSize.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn kích thước!");
            return false;
        }

        return true;
    }

    private void them() {
        if (!validateForm()) {
            return; 
        }

        try {
            SanPham sp = new SanPham();
            sp.setTen(txtTenSanPham.getText().trim());
            sp.setGia(new BigDecimal(txtGia.getText().trim()));

            SanPham createdSP = spService.themSanPham(sp);
            if (createdSP == null) {
                JOptionPane.showMessageDialog(this, "Thêm sản phẩm thất bại!");
                return;
            }

            MauSac selectedMauSac = (MauSac) cboMauSac.getSelectedItem();
            KichThuoc selectedKichThuoc = (KichThuoc) cboSize.getSelectedItem();

            BienTheSanPham bts = new BienTheSanPham();
            bts.setSanpham_id(createdSP.getId());
            bts.setMausac_id(selectedMauSac.getId());
            bts.setKichthuoc_id(selectedKichThuoc.getId());
            bts.setSoLuong(Integer.parseInt(txtSoLuong.getText().trim()));
            System.out.println("Created SanPham ID: " + createdSP.getId());

            boolean result = bienTheSanPhamSv.themBienTheSanPham(bts);
            if (!result) {
                JOptionPane.showMessageDialog(this, "Thêm biến thể sản phẩm thất bại!");
                return;
            }

            loadTableSanPham();
            clearForm();
            JOptionPane.showMessageDialog(this, "Thêm sản phẩm và biến thể thành công!");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi xảy ra khi thêm sản phẩm!");
        }
        
    }

    private void sua() {
        if (!validateForm()) {
            return;
        }

        try {
            int sanPhamId = Integer.parseInt(txtid.getText().trim());

            SanPham sp = new SanPham();
            sp.setId(sanPhamId);
            sp.setTen(txtTenSanPham.getText().trim());
            sp.setGia(new BigDecimal(txtGia.getText().trim()));

            boolean spUpdated = spService.suaSanPham(sp);
            if (!spUpdated) {
                JOptionPane.showMessageDialog(this, "Cập nhật sản phẩm thất bại!");
                return;
            }

            MauSac selectedMauSac = (MauSac) cboMauSac.getSelectedItem();
            KichThuoc selectedKichThuoc = (KichThuoc) cboSize.getSelectedItem();

            if (selectedMauSac == null || selectedKichThuoc == null) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn màu sắc và kích thước!");
                return;
            }

            BienTheSanPham bts = new BienTheSanPham();
            bts.setSanpham_id(sanPhamId);
            bts.setMausac_id(selectedMauSac.getId());
            bts.setKichthuoc_id(selectedKichThuoc.getId());
            bts.setSoLuong(Integer.parseInt(txtSoLuong.getText().trim()));

            System.out.println("Old keys: " + oldSanPhamId + ", " + oldMauSacId + ", " + oldKichThuocId);
            System.out.println("New BTS: sanpham_id=" + bts.getSanpham_id() + ", mausac_id=" + bts.getMausac_id() + ", kichthuoc_id=" + bts.getKichthuoc_id() + ", soluong=" + bts.getSoLuong());

            boolean btsUpdated = bienTheSanPhamSv.suaBienTheSanPhamTheoKey(
                    oldSanPhamId, oldMauSacId, oldKichThuocId, bts);

            if (!btsUpdated) {
                JOptionPane.showMessageDialog(this, "Cập nhật biến thể sản phẩm thất bại!");
                return;
            }

            loadTableSanPham();
            clearForm();
            JOptionPane.showMessageDialog(this, "Cập nhật sản phẩm và biến thể thành công!");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi xảy ra khi cập nhật sản phẩm!");
        }
    }

    private void getData() {
        int row = tblSanPham.getSelectedRow();
        if (row == -1) {
            return;
        }
        String id = tblSanPham.getValueAt(row, 0).toString();
        String tenSanPham = tblSanPham.getValueAt(row, 1).toString();
        String soLuong = tblSanPham.getValueAt(row, 2).toString();
        String mauSac = tblSanPham.getValueAt(row, 3).toString();
        String kichThuoc = tblSanPham.getValueAt(row, 4).toString();
        String gia = tblSanPham.getValueAt(row, 5).toString();

        txtid.setText(id);
        txtTenSanPham.setText(tenSanPham);
        txtSoLuong.setText(soLuong);
        txtGia.setText(gia);

        selectComboBoxItemByText(cboMauSac, mauSac);
        selectComboBoxItemByText(cboSize, kichThuoc);
        try {
            oldSanPhamId = Integer.parseInt(id);
            oldMauSacId = mausacService.findByName(mauSac).getId(); 
            oldKichThuocId = ktService.findByName(kichThuoc).getId();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private <T> void selectComboBoxItemByText(JComboBox<T> comboBox, String text) {
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            T item = comboBox.getItemAt(i);
            if (item.toString().equals(text)) {
                comboBox.setSelectedIndex(i);
                return;
            }
        }
    }

    private void xoa() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn xoá sản phẩm và biến thể không?",
                "Xác nhận xoá",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return; 
        }

        try {
            int sanPhamId = Integer.parseInt(txtid.getText().trim());

            MauSac selectedMauSac = (MauSac) cboMauSac.getSelectedItem();
            KichThuoc selectedKichThuoc = (KichThuoc) cboSize.getSelectedItem();

            boolean deleteBtsResult = bienTheSanPhamSv.xoaBienTheSanPhamTheoKey(sanPhamId, selectedMauSac.getId(), selectedKichThuoc.getId());
            if (!deleteBtsResult) {
                JOptionPane.showMessageDialog(this, "Xoá biến thể sản phẩm thất bại!");
                return;
            }

            boolean deleteSpResult = spService.xoaSanPham(sanPhamId);
            if (!deleteSpResult) {
                JOptionPane.showMessageDialog(this, "Xoá sản phẩm thất bại!");
                return;
            }

            loadTableSanPham();
            clearForm();
            JOptionPane.showMessageDialog(this, "Xoá sản phẩm và biến thể thành công!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID sản phẩm không hợp lệ!");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi xảy ra khi xoá sản phẩm!");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtGia = new javax.swing.JTextField();
        txtTenSanPham = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        cboMauSac = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cboSize = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        btnXoa = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("Tên Sản Phẩm:");

        jLabel3.setText("Giá:");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 204));
        jLabel1.setText("Quản Lý Sản Phẩm");

        btnThem.setText("THÊM");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("SỬA");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        jLabel4.setText("Màu Sắc:");

        jLabel5.setText("Size:");

        jLabel6.setText("Số Lượng:");

        btnXoa.setText("XOÁ");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSanPham);

        jLabel7.setText("ID:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(40, 40, 40)
                        .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cboMauSac, 0, 241, Short.MAX_VALUE)
                                    .addComponent(cboSize, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtSoLuong))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSua, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnXoa, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(33, 33, 33)
                                        .addComponent(txtGia))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(27, 27, 27)
                                        .addComponent(txtTenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnThem))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtTenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThem))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cboMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(btnSua)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(cboSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(btnXoa)))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        them();
        loadTableSanPham();
        clearForm();
    }//GEN-LAST:event_btnThemActionPerformed

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        getData();
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        sua();
        loadTableSanPham();
        clearForm();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        xoa();
        loadTableSanPham();
        clearForm();
    }//GEN-LAST:event_btnXoaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DangNhap().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<MauSac> cboMauSac;
    private javax.swing.JComboBox<KichThuoc> cboSize;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtGia;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSanPham;
    private javax.swing.JTextField txtid;
    // End of variables declaration//GEN-END:variables
}
