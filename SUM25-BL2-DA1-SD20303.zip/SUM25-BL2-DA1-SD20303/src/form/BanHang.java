/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import java.math.BigDecimal;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import models.BienTheSanPham;
import models.HoaDon;
import models.HoaDonChiTiet;
import models.GioHang;
import models.GioHangChiTiet;
import service.BienTheSanPhamService;
import service.GioHangChiTietService;
import service.GioHangService;
import service.HoaDonChiTietService;
import service.HoaDonService;

/**
 *
 * @author VIET DUC
 */
public class BanHang extends javax.swing.JFrame {

    private BienTheSanPhamService bienTheService = new BienTheSanPhamService();
    private HoaDonService hoaDonService = new HoaDonService();
    private HoaDonChiTietService chiTietHoaDonService = new HoaDonChiTietService();
    private GioHangService gioHangService = new GioHangService();
    private GioHangChiTietService gioHangChiTietService = new GioHangChiTietService();
    private String maNV;

    /**
     * Creates new form ThanhToan
     */
    public BanHang() {
        initComponents();
        this.setLocationRelativeTo(null);
        JScrollPane scrollPane = new JScrollPane(jPanel1);
        setContentPane(scrollPane);
        loadSanPham();
        loadThanhToan();
        loadTableGioHang();
    }

    public BanHang(String maNV) {
        initComponents();
        this.maNV = maNV;
        this.setLocationRelativeTo(null);
        JScrollPane scrollPane = new JScrollPane(jPanel1);
        setContentPane(scrollPane);
        loadSanPham();
        loadThanhToan();
        loadTableGioHang();
    }

    private void loadSanPham() {
        DefaultTableModel modelSanPham = (DefaultTableModel) tblSanPham.getModel();
        modelSanPham.setRowCount(0);
        modelSanPham.setColumnIdentifiers(new String[]{"ID", "Tên sản phẩm", "Màu sắc", "Kích thước", "Số lượng", "Giá bán"});
        List<BienTheSanPham> listSanPham = bienTheService.getAllBienTheSanPham();
        for (BienTheSanPham sp : listSanPham) {
            modelSanPham.addRow(new Object[]{
                sp.getId(),
                sp.getTenSanPham(),
                sp.getMauSac(),
                sp.getKichThuoc(),
                sp.getSoLuong(),
                sp.getGiaBan()
            });
        }
    }

    private void loadThanhToan() {
        DefaultTableModel modelThanhToan = (DefaultTableModel) tblThanhToan.getModel();
        modelThanhToan.setRowCount(0);

        modelThanhToan.setColumnIdentifiers(new String[]{
            "Mã HĐ", "Ngày Tạo", "Tổng Tiền", "Mã NV", "Tổng Số Lượng"
        });

        List<HoaDon> listHoaDon = hoaDonService.getAllHoaDon();

        for (HoaDon hd : listHoaDon) {
            int tongSoLuong = chiTietHoaDonService.getTongSoLuongByMaHD(hd.getMaHoaDon());

            modelThanhToan.addRow(new Object[]{
                hd.getMaHoaDon(),
                hd.getNgayTao(),
                hd.getTongTien(),
                hd.getMaNV(),
                tongSoLuong
            });
        }
    }

    private void loadTableGioHang() {
        GioHang gioHang = gioHangService.layGioHangHienTai(maNV);
        DefaultTableModel model = (DefaultTableModel) tblGioHang.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID Biến thể", "ID Chi tiết", 
            "Tên sản phẩm", "Màu sắc", "Kích thước", "Số lượng", "Giá bán", "Thành tiền"
        });

        model.setRowCount(0);

        if (gioHang == null) {
            return;
        }

        List<GioHangChiTiet> chiTiets = gioHangChiTietService.getAllByGioHangId(gioHang.getId());

        for (GioHangChiTiet ct : chiTiets) {
            BienTheSanPham bt = bienTheService.getBienTheTheoId(ct.getBienthe_id());

            String tenSanPham = bt.getTenSanPham();
            String mauSac = bt.getMauSac();
            String kichThuoc = bt.getKichThuoc();

            int soLuong = ct.getSoLuong();
            BigDecimal giaBan = bt.getGiaBan();
            BigDecimal thanhTien = giaBan.multiply(new BigDecimal(soLuong));

            model.addRow(new Object[]{
                bt.getId(),
                ct.getId(),
                tenSanPham,
                mauSac,
                kichThuoc,
                soLuong,
                giaBan,
                thanhTien
            });
        }

        tblGioHang.getColumnModel().getColumn(0).setMinWidth(0);
        tblGioHang.getColumnModel().getColumn(0).setMaxWidth(0);
        tblGioHang.getColumnModel().getColumn(0).setWidth(0);

        tblGioHang.getColumnModel().getColumn(1).setMinWidth(0);
        tblGioHang.getColumnModel().getColumn(1).setMaxWidth(0);
        tblGioHang.getColumnModel().getColumn(1).setWidth(0);
    }

    private void themGioHang() {
        int selectedRow = tblSanPham.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm để thêm vào giỏ hàng.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) tblSanPham.getModel();
        int bienTheId;
        try {
            bienTheId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID biến thể không hợp lệ!");
            return;
        }

        String input = JOptionPane.showInputDialog(this, "Nhập số lượng:");
        int soLuong;
        try {
            soLuong = Integer.parseInt(input);
            if (soLuong <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ!");
            return;
        }
        int soLuongTonKho = bienTheService.getSoLuongTonTheoBienThe(bienTheId);

        if (soLuong > soLuongTonKho) {
            JOptionPane.showMessageDialog(this, "Số lượng yêu cầu vượt quá số lượng tồn kho (" + soLuongTonKho + ").");
            return;
        }

        GioHang gioHang = gioHangService.layGioHangHienTai(maNV);

        if (gioHang == null) {
            int idGioHangMoi = gioHangService.taoGioHangMoi(maNV);
            if (idGioHangMoi == -1) {
                JOptionPane.showMessageDialog(this, "Không thể tạo giỏ hàng mới.");
                return;
            }
            gioHang = gioHangService.layGioHangHienTai(maNV);
            if (gioHang == null) {
                JOptionPane.showMessageDialog(this, "Lỗi khi lấy giỏ hàng mới tạo.");
                return;
            }
        }

        GioHangChiTiet chiTiet = new GioHangChiTiet();
        chiTiet.setGioHang_id(gioHang.getId());
        chiTiet.setBienthe_id(bienTheId);
        chiTiet.setSoLuong(soLuong);

        boolean success = gioHangChiTietService.addOrUpdate(chiTiet);

        if (success) {
            JOptionPane.showMessageDialog(this, "Thêm vào giỏ hàng thành công!");
            loadTableGioHang();
        } else {
            JOptionPane.showMessageDialog(this, "Không thể thêm vào giỏ hàng!");
        }
    }

    private void thanhToan() {
        GioHang gioHang = gioHangService.layGioHangHienTai(maNV);

        if (gioHang == null) {
            JOptionPane.showMessageDialog(this, "Không có giỏ hàng để thanh toán.");
            return;
        }

        List<GioHangChiTiet> chiTietGioHang = gioHangChiTietService.getAllByGioHangId(gioHang.getId());
        if (chiTietGioHang.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Giỏ hàng trống.");
            return;
        }

        BigDecimal tongTien = BigDecimal.ZERO;
        for (GioHangChiTiet ct : chiTietGioHang) {
            BienTheSanPham bts = bienTheService.getBienTheTheoId(ct.getBienthe_id());
            if (bts == null) {
                continue;
            }
            BigDecimal thanhTien = bts.getGiaBan().multiply(BigDecimal.valueOf(ct.getSoLuong()));
            tongTien = tongTien.add(thanhTien);
        }

        HoaDon hd = new HoaDon();
        hd.setNgayTao(new java.util.Date());
        hd.setTongTien(tongTien);
        hd.setMaNV(maNV);

        int maHD = hoaDonService.themHoaDon(hd);
        if (maHD == -1) {
            JOptionPane.showMessageDialog(this, "Không thể tạo hóa đơn.");
            return;
        }

        for (GioHangChiTiet ct : chiTietGioHang) {
            BienTheSanPham bts = bienTheService.getBienTheTheoId(ct.getBienthe_id());
            if (bts == null) {
                continue;
            }

            HoaDonChiTiet cthd = new HoaDonChiTiet();
            cthd.setMa_hd(maHD);
            cthd.setBienthe_id(bts.getId());
            cthd.setSoLuong(ct.getSoLuong());
            cthd.setGiaBan(bts.getGiaBan());

            if (!chiTietHoaDonService.themChiTiet(cthd)) {
                JOptionPane.showMessageDialog(this, "Không thể thêm chi tiết hóa đơn.");
                return;
            }

            if (!bienTheService.capNhatSoLuongSauKhiBan(bts.getId(), ct.getSoLuong())) {
                JOptionPane.showMessageDialog(this, "Không thể cập nhật tồn kho cho sản phẩm.");
                return;
            }
        }

        if (!gioHangService.xoaGioHang(gioHang.getId())) {
            JOptionPane.showMessageDialog(this, "Lỗi khi xóa giỏ hàng sau thanh toán.");
            return;
        }

        JOptionPane.showMessageDialog(this, "Thanh toán thành công!");

        StringBuilder sb = new StringBuilder();
        sb.append("=== HÓA ĐƠN THANH TOÁN ===\n");
        sb.append("Mã HĐ: ").append(maHD).append("\n");
        sb.append("Ngày tạo: ").append(new java.util.Date()).append("\n");
        sb.append("Nhân viên: ").append(maNV).append("\n\n");

        BigDecimal tongTienHD = BigDecimal.ZERO;
        int tongSoLuong = 0;

        for (GioHangChiTiet ct : chiTietGioHang) {
            BienTheSanPham bts = bienTheService.getBienTheTheoId(ct.getBienthe_id());
            if (bts == null) {
                continue;
            }

            BigDecimal thanhTien = bts.getGiaBan().multiply(BigDecimal.valueOf(ct.getSoLuong()));
            tongTienHD = tongTienHD.add(thanhTien);
            tongSoLuong += ct.getSoLuong();

            sb.append("- ").append(bts.getTenSanPham())
                    .append(" | Màu: ").append(bts.getMauSac())
                    .append(" | Size: ").append(bts.getKichThuoc())
                    .append(" | SL: ").append(ct.getSoLuong())
                    .append(" | Giá: ").append(bts.getGiaBan())
                    .append(" | Thành tiền: ").append(thanhTien)
                    .append("\n");
        }

        sb.append("\nTổng số lượng: ").append(tongSoLuong);
        sb.append("\nTổng tiền: ").append(tongTienHD).append(" VND");

        JOptionPane.showMessageDialog(this, sb.toString(), "Thông tin hóa đơn", JOptionPane.INFORMATION_MESSAGE);

        loadTableGioHang();
        loadThanhToan();
        loadSanPham();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnGioHang = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblThanhToan = new javax.swing.JTable();
        btnThanhToan = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 204, 204));
        jLabel5.setText("BÁN HÀNG");

        jLabel1.setText("danh sách sản phẩm:");

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblSanPham);

        btnGioHang.setText("THÊM VÀO GIỎ HÀNG");
        btnGioHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGioHangActionPerformed(evt);
            }
        });

        jLabel2.setText("Giỏ hàng:");

        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblGioHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGioHangMouseClicked(evt);
            }
        });
        tblGioHang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tblGioHangKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblGioHang);

        jLabel3.setText("Thanh Toán:");

        tblThanhToan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblThanhToan);

        btnThanhToan.setText("THANH TOÁN");
        btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnGioHang)
                                .addGap(16, 16, 16))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(btnThanhToan)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel5)
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(btnGioHang))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(6, 6, 6)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnThanhToan)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGioHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGioHangActionPerformed
        themGioHang();
        loadTableGioHang();
        loadSanPham();
    }//GEN-LAST:event_btnGioHangActionPerformed

    private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToanActionPerformed
        thanhToan();
    }//GEN-LAST:event_btnThanhToanActionPerformed

    private void tblGioHangKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tblGioHangKeyPressed
    }//GEN-LAST:event_tblGioHangKeyPressed

    private void tblGioHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGioHangMouseClicked
        int row = tblGioHang.getSelectedRow();
        if (row == -1) {
            return;
        }

        try {
            int bienTheId = Integer.parseInt(tblGioHang.getValueAt(row, 0).toString()); // bt.getId()
            int soLuongCu = Integer.parseInt(tblGioHang.getValueAt(row, 4).toString()); // "Số lượng" ở cột 4

            String nhap = JOptionPane.showInputDialog(this, "Nhập số lượng mới:", soLuongCu);

            if (nhap == null || nhap.trim().isEmpty()) {
                return;
            }

            int soLuongMoi;

            try {
                soLuongMoi = Integer.parseInt(nhap.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập số nguyên hợp lệ.");
                return;
            }

            if (soLuongMoi < 0) {
                JOptionPane.showMessageDialog(this, "Số lượng không được âm.");
                return;
            }

            GioHang gioHang = gioHangService.layGioHangHienTai(maNV);
            if (gioHang == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy giỏ hàng.");
                return;
            }

            boolean success;
            if (soLuongMoi == 0) {
                success = gioHangChiTietService.deleteByBienThe(gioHang.getId(), bienTheId);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Đã xóa sản phẩm khỏi giỏ hàng.");
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa thất bại.");
                }
            } else {
                success = gioHangChiTietService.updateSoLuong(gioHang.getId(), bienTheId, soLuongMoi);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Cập nhật thành công.");
                } else {
                    JOptionPane.showMessageDialog(this, "Cập nhật thất bại.");
                }
            }

            loadTableGioHang();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Đã xảy ra lỗi: " + e.getMessage());
        }
    }//GEN-LAST:event_tblGioHangMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DangNhap().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGioHang;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tblGioHang;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTable tblThanhToan;
    // End of variables declaration//GEN-END:variables
}
