/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.*;
import models.HoaDon;
import static repository.ConnectionDataBase.getConnection;

/**
 *
 * @author VIET DUC
 */
public class HoaDonRepository {

    public int themHoaDon(HoaDon hd) {
        String sql = "INSERT INTO HoaDon (NgayTao, TongTien, MaNV) OUTPUT INSERTED.MaHD VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, new Timestamp(hd.getNgayTao().getTime()));
            ps.setBigDecimal(2, hd.getTongTien());
            ps.setString(3, hd.getMaNV());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1); // Trả về MaHD vừa tạo
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public List<HoaDon> getAllHoaDon() {
        List<HoaDon> list = new ArrayList<>();
        String sql = "SELECT * FROM HoaDon";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("MaHD"));
                hd.setNgayTao(rs.getTimestamp("NgayTao"));
                hd.setTongTien(rs.getBigDecimal("TongTien"));
                hd.setMaNV(rs.getString("MaNV"));
                list.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean xoaHoaDon(int maHD) {
        String sql = "DELETE FROM HoaDon WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maHD);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public HoaDon getHoaDonById(int maHD) {
        String sql = "SELECT * FROM HoaDon WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maHD);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("MaHD"));
                hd.setNgayTao(rs.getTimestamp("NgayTao"));
                hd.setTongTien(rs.getBigDecimal("TongTien"));
                hd.setMaNV(rs.getString("MaNV"));
                return hd;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateHoaDon(HoaDon hd) {
        String sql = "UPDATE HoaDon SET NgayTao = ?, TongTien = ?, MaNV = ? WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, new Timestamp(hd.getNgayTao().getTime()));
            ps.setBigDecimal(2, hd.getTongTien());
            ps.setString(3, hd.getMaNV());
            ps.setInt(4, hd.getMaHoaDon()); 
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
