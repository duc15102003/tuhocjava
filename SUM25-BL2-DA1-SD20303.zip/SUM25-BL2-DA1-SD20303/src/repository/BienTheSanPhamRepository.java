/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.BienTheSanPham;


public class BienTheSanPhamRepository {

    public boolean themBienTheSanPham(BienTheSanPham bienTheSanPham) {
        String sql = "INSERT INTO BienTheSanPham (sanpham_id, mausac_id, kichthuoc_id, soluong) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bienTheSanPham.getSanpham_id());
            ps.setInt(2, bienTheSanPham.getMausac_id());
            ps.setInt(3, bienTheSanPham.getKichthuoc_id());
            ps.setInt(4, bienTheSanPham.getSoLuong());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<BienTheSanPham> getAllBienTheSanPham() {
        List<BienTheSanPham> list = new ArrayList<>();
        String sql = "SELECT b.id, b.sanpham_id, b.mausac_id, b.kichthuoc_id, s.ten AS ten_sanpham, m.ten AS ten_mausac, k.size AS kichthuoc, b.soluong, s.gia AS gia_ban "
                + "FROM BienTheSanPham b "
                + "JOIN SanPham s ON b.sanpham_id = s.id "
                + "JOIN MauSac m ON b.mausac_id = m.id "
                + "JOIN KichThuoc k ON b.kichthuoc_id = k.id";
        try (Connection conn = ConnectionDataBase.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                BienTheSanPham bts = new BienTheSanPham();
                bts.setId(rs.getInt("id"));
                bts.setSanpham_id(rs.getInt("sanpham_id")); 
                bts.setMausac_id(rs.getInt("mausac_id"));   
                bts.setKichthuoc_id(rs.getInt("kichthuoc_id")); 
                bts.setSoLuong(rs.getInt("soluong"));

                bts.setTenSanPham(rs.getString("ten_sanpham"));
                bts.setMauSac(rs.getString("ten_mausac"));
                bts.setKichThuoc(rs.getString("kichthuoc"));
                bts.setGiaBan(rs.getBigDecimal("gia_ban"));

                list.add(bts);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean suaBienTheSanPhamTheoKey(int oldSanPhamId, int oldMauSacId, int oldKichThuocId, BienTheSanPham newBts) {
        String sql = "UPDATE BienTheSanPham SET sanpham_id = ?, mausac_id = ?, kichthuoc_id = ?, soluong = ? "
                + "WHERE sanpham_id = ? AND mausac_id = ? AND kichthuoc_id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, newBts.getSanpham_id());
            ps.setInt(2, newBts.getMausac_id());
            ps.setInt(3, newBts.getKichthuoc_id());
            ps.setInt(4, newBts.getSoLuong());

            ps.setInt(5, oldSanPhamId);
            ps.setInt(6, oldMauSacId);
            ps.setInt(7, oldKichThuocId);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean xoaBienTheSanPhamTheoKey(int sanPhamId, int mauSacId, int kichThuocId) {
        String sql = "DELETE FROM BienTheSanPham WHERE sanpham_id = ? AND mausac_id = ? AND kichthuoc_id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sanPhamId);
            ps.setInt(2, mauSacId);
            ps.setInt(3, kichThuocId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public BienTheSanPham findBySanPhamMauSize(int sanPhamId, int mauSacId, int kichThuocId) {
        String sql = "SELECT * FROM BienTheSanPham WHERE sanpham_id = ? AND mausac_id = ? AND kichthuoc_id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sanPhamId);
            ps.setInt(2, mauSacId);
            ps.setInt(3, kichThuocId);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new BienTheSanPham(
                        rs.getInt("id"),
                        rs.getInt("sanpham_id"),
                        rs.getInt("mausac_id"),
                        rs.getInt("kichthuoc_id"),
                        rs.getInt("soluong")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getSoLuongTon(int sanphamId) {
        String sql = "SELECT SUM(soluong) AS tong_so_luong FROM BienTheSanPham WHERE sanpham_id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sanphamId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("tong_so_luong");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean capNhatSoLuongSauKhiBan(int bienTheId, int soLuongTru) {
        if (soLuongTru <= 0) {
            System.out.println("Số lượng trừ phải > 0");
            return false;
        }
        String sqlSelect = "SELECT soluong FROM BienTheSanPham WHERE id = ?";
        String sqlUpdate = "UPDATE BienTheSanPham SET soluong = ? WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection()) {
            int soLuongHienTai = 0;
            try (PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {
                psSelect.setInt(1, bienTheId);
                ResultSet rs = psSelect.executeQuery();
                if (rs.next()) {
                    soLuongHienTai = rs.getInt("soluong");
                } else {
                    System.out.println("Không tìm thấy biến thể sản phẩm với id = " + bienTheId);
                    return false;
                }
            }
            if (soLuongHienTai < soLuongTru) {
                System.out.println("Số lượng hiện tại không đủ để trừ");
                return false;
            }
            int soLuongMoi = soLuongHienTai - soLuongTru;
            try (PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {
                psUpdate.setInt(1, soLuongMoi);
                psUpdate.setInt(2, bienTheId);
                int rowsUpdated = psUpdate.executeUpdate();
                return rowsUpdated > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public int getSoLuongTonTheoBienThe(int bienTheId) {
        String sql = "SELECT soluong FROM BienTheSanPham WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bienTheId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("soluong");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public BienTheSanPham getBienTheTheoId(int id) {
        String sql = "SELECT b.id, b.sanpham_id, b.mausac_id, b.kichthuoc_id, b.soluong, "
                + "s.ten AS ten_sanpham, m.ten AS ten_mausac, k.size AS kichthuoc, s.gia AS gia_ban "
                + "FROM BienTheSanPham b "
                + "JOIN SanPham s ON b.sanpham_id = s.id "
                + "JOIN MauSac m ON b.mausac_id = m.id "
                + "JOIN KichThuoc k ON b.kichthuoc_id = k.id "
                + "WHERE b.id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                BienTheSanPham bts = new BienTheSanPham();
                bts.setId(rs.getInt("id"));
                bts.setSanpham_id(rs.getInt("sanpham_id"));
                bts.setMausac_id(rs.getInt("mausac_id"));
                bts.setKichthuoc_id(rs.getInt("kichthuoc_id"));
                bts.setSoLuong(rs.getInt("soluong"));
                bts.setTenSanPham(rs.getString("ten_sanpham"));
                bts.setMauSac(rs.getString("ten_mausac"));
                bts.setKichThuoc(rs.getString("kichthuoc"));
                bts.setGiaBan(rs.getBigDecimal("gia_ban"));
                return bts;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
