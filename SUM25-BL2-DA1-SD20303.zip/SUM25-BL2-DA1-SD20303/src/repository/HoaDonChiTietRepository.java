/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.*;
import models.HoaDonChiTiet;
import static repository.ConnectionDataBase.getConnection;

/**
 *
 * @author VIET DUC
 */
public class HoaDonChiTietRepository {

    public boolean themChiTietHoaDon(HoaDonChiTiet ct) {
        String sql = "INSERT INTO ChiTietHoaDon (MaHD, BienThe_id, soluong, giaban) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ct.getMa_hd());
            ps.setInt(2, ct.getBienthe_id());  
            ps.setInt(3, ct.getSoLuong());
            ps.setBigDecimal(4, ct.getGiaBan());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<HoaDonChiTiet> getByMaHD(int maHD) {
        List<HoaDonChiTiet> list = new ArrayList<>();
        String sql = "SELECT * FROM ChiTietHoaDon WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maHD);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                HoaDonChiTiet ct = new HoaDonChiTiet();
                ct.setId(rs.getInt("id"));
                ct.setMa_hd(rs.getInt("MaHD"));
                ct.setBienthe_id(rs.getInt("BienThe_id"));  
                ct.setSoLuong(rs.getInt("soluong"));
                ct.setGiaBan(rs.getBigDecimal("giaban"));
                list.add(ct);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getTongSoLuongByMaHD(int maHD) {
        String sql = "SELECT SUM(soluong) AS TongSoLuong FROM ChiTietHoaDon WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maHD);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("TongSoLuong");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean xoaChiTietHoaDon(int id) {
        String sql = "DELETE FROM ChiTietHoaDon WHERE MaHD = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateChiTietHoaDon(HoaDonChiTiet ct) {
        String sql = "UPDATE ChiTietHoaDon SET soluong = ?, giaban = ? WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ct.getSoLuong());
            ps.setBigDecimal(2, ct.getGiaBan());
            ps.setInt(3, ct.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
