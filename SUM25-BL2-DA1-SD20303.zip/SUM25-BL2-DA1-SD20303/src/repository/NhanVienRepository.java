/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import models.NhanVien;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author VIET DUC
 */
public class NhanVienRepository {

    public boolean insertNhanVien(NhanVien nv) {
        String sql = "INSERT INTO NhanVien (MaNV, HoTen, taikhoan, MatKhau, VaiTro) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getMaNv());
            ps.setString(2, nv.getHoTen());
            ps.setString(3, nv.getTaiKhoan());
            ps.setString(4, nv.getMatKhau());
            ps.setString(5, nv.getVaiTro());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<NhanVien> getAllNhanVien() {
        List<NhanVien> list = new ArrayList<>();
        String sql = "SELECT * FROM NhanVien";
        try (Connection conn = ConnectionDataBase.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                NhanVien nv = new NhanVien(
                        rs.getString("MaNV"),
                        rs.getString("HoTen"),
                        rs.getString("taikhoan"),
                        rs.getString("MatKhau"),
                        rs.getString("VaiTro")
                );
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public NhanVien getNhanVienById(String maNV) {
        String sql = "SELECT * FROM NhanVien WHERE MaNV = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new NhanVien(
                        rs.getString("MaNV"),
                        rs.getString("HoTen"),
                        rs.getString("taikhoan"),
                        rs.getString("MatKhau"),
                        rs.getString("VaiTro")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateNhanVien(NhanVien nv) {
        String sql = "UPDATE NhanVien SET HoTen = ?, taikhoan = ?, MatKhau = ?, VaiTro = ? WHERE MaNV = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getHoTen());
            ps.setString(2, nv.getTaiKhoan());
            ps.setString(3, nv.getMatKhau());
            ps.setString(4, nv.getVaiTro());
            ps.setString(5, nv.getMaNv());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteNhanVien(String maNV) {
        String sql = "DELETE FROM NhanVien WHERE MaNV = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maNV);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean tonTaiTaiKhoan(String taiKhoan) {
        String sql = "SELECT COUNT(*) FROM NhanVien WHERE taikhoan = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, taiKhoan);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public NhanVien dangNhap(String taiKhoan, String matKhau) {
        String sql = "SELECT * FROM NhanVien WHERE taiKhoan = ? AND matKhau = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, taiKhoan);
            ps.setString(2, matKhau);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new NhanVien(
                        rs.getString("maNv"),
                        rs.getString("hoTen"),
                        rs.getString("taiKhoan"),
                        rs.getString("matKhau"),
                        rs.getString("vaiTro")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null; 
    }

}
