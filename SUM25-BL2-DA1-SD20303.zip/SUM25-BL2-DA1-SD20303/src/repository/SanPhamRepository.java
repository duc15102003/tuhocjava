/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.SanPham;

/**
 *
 * @author VIET DUC
 */
public class SanPhamRepository {

    public SanPham themSanPham(SanPham sp) {
        String sql = "INSERT INTO sanpham (ten, gia) VALUES (?, ?)";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, sp.getTen());
            ps.setBigDecimal(2, sp.getGia());
            int affected = ps.executeUpdate();

            if (affected > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    sp.setId(rs.getInt(1)); 
                    return sp;  
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;  
    }

    public boolean suaSanPham(SanPham sp) {
        String sql = "UPDATE sanpham SET ten = ?, gia = ? WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sp.getTen());
            ps.setBigDecimal(2, sp.getGia());
            ps.setInt(3, sp.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean xoaSanPham(int id) {
        String sql = "DELETE FROM sanpham WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Object[]> layDanhSachSanPhamFull() {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT sp.id AS sanpham_id, sp.ten, bts.soluong, ms.ten AS mausac, kt.size AS kichthuoc, sp.gia "
                + "FROM sanpham sp "
                + "JOIN BienTheSanPham bts ON sp.id = bts.sanpham_id "
                + "JOIN MauSac ms ON bts.mausac_id = ms.id "
                + "JOIN KichThuoc kt ON bts.kichthuoc_id = kt.id "
                + "ORDER BY sp.id";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Object[] row = new Object[6];
                row[0] = rs.getInt("sanpham_id");
                row[1] = rs.getString("ten");
                row[2] = rs.getInt("soluong");
                row[3] = rs.getString("mausac");
                row[4] = rs.getInt("kichthuoc");
                row[5] = rs.getBigDecimal("gia");
                list.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
