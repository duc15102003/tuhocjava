/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;
import java.sql.*;
import models.GioHang;
/**
 *
 * @author VIET DUC
 */
public class GioHangRepository {
    public int createGioHang(String maNV) {
        String sql = "INSERT INTO GioHang (MaNV) VALUES (?)";
        try (Connection conn = ConnectionDataBase.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, maNV);
            int affectedRows = ps.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Tạo giỏ hàng thất bại, không có dòng nào bị ảnh hưởng.");
            }

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Tạo giỏ hàng thất bại, không lấy được ID.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;  
    }

    public GioHang getGioHangMoiNhatTheoMaNV(String maNV) {
        String sql = "SELECT TOP 1 id, MaNV, NgayTao FROM GioHang WHERE MaNV = ? ORDER BY NgayTao DESC";
        try (Connection conn = ConnectionDataBase.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maNV);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                GioHang gh = new GioHang();
                gh.setId(rs.getInt("id"));
                gh.setMaNV(rs.getString("MaNV"));
                gh.setNgayTao(new java.util.Date(rs.getTimestamp("NgayTao").getTime())); 
                return gh;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; 
    }

    public boolean deleteGioHang(int id) {
        String sql = "DELETE FROM GioHang WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public int demSoLuongSanPhamTrongGio(int gioHangId) {
    String sql = "SELECT COUNT(*) FROM GioHangChiTiet WHERE giohang_id = ?";
    try (Connection conn = ConnectionDataBase.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, gioHangId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}
}
