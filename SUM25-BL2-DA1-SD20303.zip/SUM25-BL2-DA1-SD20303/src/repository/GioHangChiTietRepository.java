/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.GioHangChiTiet;

/**
 *
 * @author VIET DUC
 */
public class GioHangChiTietRepository {

    public boolean addOrUpdate(GioHangChiTiet chiTiet) {
        String sqlCheck = "SELECT id, soLuong FROM GioHangChiTiet WHERE gioHang_id = ? AND bienthe_id = ?";
        String sqlInsert = "INSERT INTO GioHangChiTiet (gioHang_id, bienthe_id, soLuong) VALUES (?, ?, ?)";
        String sqlUpdate = "UPDATE GioHangChiTiet SET soLuong = soLuong + ? WHERE id = ?";

        try (Connection conn = ConnectionDataBase.getConnection()) {
            try (PreparedStatement psCheck = conn.prepareStatement(sqlCheck)) {
                psCheck.setInt(1, chiTiet.getGioHang_id());
                psCheck.setInt(2, chiTiet.getBienthe_id());
                ResultSet rs = psCheck.executeQuery();

                if (rs.next()) {
                    int id = rs.getInt("id");
                    try (PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {
                        psUpdate.setInt(1, chiTiet.getSoLuong());
                        psUpdate.setInt(2, id);
                        psUpdate.executeUpdate();
                    }
                } else {
                    try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                        psInsert.setInt(1, chiTiet.getGioHang_id());
                        psInsert.setInt(2, chiTiet.getBienthe_id());
                        psInsert.setInt(3, chiTiet.getSoLuong());
                        psInsert.executeUpdate();
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public GioHangChiTiet getChiTietByGioHangAndBienThe(int gioHangId, int bienTheId) {
        String sql = "SELECT id, gioHang_id, bienthe_id, soLuong FROM GioHangChiTiet WHERE gioHang_id = ? AND bienthe_id = ?";

        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, gioHangId);
            ps.setInt(2, bienTheId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                GioHangChiTiet ct = new GioHangChiTiet();
                ct.setId(rs.getInt("id"));
                ct.setGioHang_id(rs.getInt("gioHang_id"));
                ct.setBienthe_id(rs.getInt("bienthe_id"));
                ct.setSoLuong(rs.getInt("soLuong"));
                return ct;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean deleteById(int id) {
        String sql = "DELETE FROM GioHangChiTiet WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<GioHangChiTiet> getAllByGioHangId(int gioHangId) {
        List<GioHangChiTiet> list = new ArrayList<>();
        String sql = "SELECT id, gioHang_id, bienthe_id, soLuong FROM GioHangChiTiet WHERE gioHang_id = ?";

        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, gioHangId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                GioHangChiTiet chiTiet = new GioHangChiTiet();
                chiTiet.setId(rs.getInt("id"));
                chiTiet.setGioHang_id(rs.getInt("gioHang_id"));
                chiTiet.setBienthe_id(rs.getInt("bienthe_id"));
                chiTiet.setSoLuong(rs.getInt("soLuong"));
                list.add(chiTiet);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean updateSoLuong(int gioHangId, int bienTheId, int soLuongMoi) {
        String sql = "UPDATE GioHangChiTiet SET soLuong = ? WHERE gioHang_id = ? AND bienthe_id = ?";

        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, soLuongMoi);
            ps.setInt(2, gioHangId);
            ps.setInt(3, bienTheId);

            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean deleteByBienThe(int gioHangId, int bienTheId) {
        String sql = "DELETE FROM GioHangChiTiet WHERE gioHang_id = ? AND bienthe_id = ?";

        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, gioHangId);
            ps.setInt(2, bienTheId);

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
