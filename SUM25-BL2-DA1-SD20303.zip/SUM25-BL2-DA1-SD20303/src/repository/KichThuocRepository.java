/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.KichThuoc;

/**
 *
 * @author VIET DUC
 */
public class KichThuocRepository {

    public boolean themKichThuoc(KichThuoc kichThuoc) {
        String sql = "INSERT INTO KichThuoc (size) VALUES (?)";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, kichThuoc.getTen());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<KichThuoc> getAllKichThuoc() {
        List<KichThuoc> list = new ArrayList<>();
        String sql = "SELECT * FROM KichThuoc";
        try (Connection conn = ConnectionDataBase.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                KichThuoc kichThuoc = new KichThuoc(rs.getInt("id"), rs.getInt("size"));
                list.add(kichThuoc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public KichThuoc findByName(String ten) {
        String sql = "SELECT * FROM KichThuoc WHERE size = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(ten)); // Vì kích thước là số
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new KichThuoc(rs.getInt("id"), rs.getInt("size"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean suaKichThuoc(KichThuoc kichThuoc) {
        String sql = "UPDATE KichThuoc SET size = ? WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, kichThuoc.getTen());
            ps.setInt(2, kichThuoc.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean xoaKichThuoc(int id) {
        String sql = "DELETE FROM KichThuoc WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
