/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import models.MauSac;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author VIET DUC
 */
public class MauSacRepository {

    public boolean themMauSac(MauSac mauSac) {
        String sql = "INSERT INTO MauSac (ten) VALUES (?)";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mauSac.getTen());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<MauSac> getAllMauSac() {
        List<MauSac> list = new ArrayList<>();
        String sql = "SELECT * FROM MauSac";
        try (Connection conn = ConnectionDataBase.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                MauSac mauSac = new MauSac(rs.getInt("id"), rs.getString("ten"));
                list.add(mauSac);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public MauSac findByName(String ten) {
        String sql = "SELECT * FROM MauSac WHERE ten = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ten);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new MauSac(rs.getInt("id"), rs.getString("ten"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean suaMauSac(MauSac mauSac) {
        String sql = "UPDATE MauSac SET ten = ? WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mauSac.getTen());
            ps.setInt(2, mauSac.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean xoaMauSac(int id) {
        String sql = "DELETE FROM MauSac WHERE id = ?";
        try (Connection conn = ConnectionDataBase.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
