/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.KichThuoc;
import repository.KichThuocRepository;

/**
 *
 * @author VIET DUC
 */
public class KichThuocService {

    private KichThuocRepository kichThuocRepo = new KichThuocRepository();

    public List<KichThuoc> getAllKichThuoc() {
        return kichThuocRepo.getAllKichThuoc();
    }

    public KichThuoc findByName(String sizeStr) {
        return kichThuocRepo.findByName(sizeStr);
    }

    public boolean themKichThuoc(KichThuoc kichThuoc) {
        return kichThuocRepo.themKichThuoc(kichThuoc);
    }

    public boolean suaKichThuoc(KichThuoc kichThuoc) {
        return kichThuocRepo.suaKichThuoc(kichThuoc);
    }

    public boolean xoaKichThuoc(int id) {
        return kichThuocRepo.xoaKichThuoc(id);
    }
}
