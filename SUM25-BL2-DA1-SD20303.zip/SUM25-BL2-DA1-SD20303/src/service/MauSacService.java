/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import repository.MauSacRepository;
import models.MauSac;

/**
 *
 * @author VIET DUC
 */
public class MauSacService {

    private MauSacRepository mauSacRepo = new MauSacRepository();

    public List<MauSac> getAllMauSac() {
        return mauSacRepo.getAllMauSac();
    }

    public MauSac findByName(String ten) {
        return mauSacRepo.findByName(ten);
    }

    public boolean themMauSac(MauSac mauSac) {
        return mauSacRepo.themMauSac(mauSac);
    }

    public boolean suaMauSac(MauSac mauSac) {
        return mauSacRepo.suaMauSac(mauSac);
    }

    public boolean xoaMauSac(int id) {
        return mauSacRepo.xoaMauSac(id);
    }
}
