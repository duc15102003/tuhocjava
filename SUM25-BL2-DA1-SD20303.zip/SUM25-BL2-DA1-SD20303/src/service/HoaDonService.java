/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import repository.HoaDonRepository;
import models.HoaDon;

/**
 *
 * @author VIET DUC
 */
public class HoaDonService {

    private HoaDonRepository repo = new HoaDonRepository();

    public int themHoaDon(HoaDon hd) {
        return repo.themHoaDon(hd);
    }

    public List<HoaDon> getAllHoaDon() {
        return repo.getAllHoaDon();
    }

    public boolean xoaHoaDon(int maHD) {
        return repo.xoaHoaDon(maHD);
    }

    public HoaDon getHoaDonById(int maHD) {
        return repo.getHoaDonById(maHD);
    }
        public boolean updateHoaDon(HoaDon hd) {
        return repo.updateHoaDon(hd);
    }
}
