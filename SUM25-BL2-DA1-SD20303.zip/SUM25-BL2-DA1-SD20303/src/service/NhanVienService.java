/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.NhanVien;
import repository.NhanVienRepository;

/**
 *
 * @author VIET DUC
 */
public class NhanVienService {

    private NhanVienRepository repository;

    public NhanVienService() {
        repository = new NhanVienRepository();
    }

    // Thêm nhân viên
    public boolean themNhanVien(NhanVien nv) {
        if (nv == null
                || nv.getMaNv().isEmpty()
                || nv.getHoTen().isEmpty()
                || nv.getTaiKhoan().isEmpty()
                || nv.getMatKhau().isEmpty()
                || nv.getVaiTro().isEmpty()) {
            System.out.println("Thông tin nhân viên không hợp lệ.");
            return false;
        }

        if (repository.tonTaiTaiKhoan(nv.getTaiKhoan())) {
            System.out.println("Tài khoản đã tồn tại.");
            return false;
        }

        return repository.insertNhanVien(nv);
    }

    public boolean suaNhanVien(NhanVien nv) {
        if (nv == null || nv.getMaNv().isEmpty()) {
            System.out.println("Thông tin nhân viên không hợp lệ.");
            return false;
        }

        return repository.updateNhanVien(nv);
    }

    public boolean xoaNhanVien(String maNV) {
        if (maNV == null || maNV.isEmpty()) {
            System.out.println("Mã nhân viên không hợp lệ.");
            return false;
        }
        return repository.deleteNhanVien(maNV);
    }

    public List<NhanVien> layDanhSachNhanVien() {
        return repository.getAllNhanVien();
    }

    public NhanVien timNhanVienTheoMa(String maNV) {
        if (maNV == null || maNV.isEmpty()) {
            return null;
        }
        return repository.getNhanVienById(maNV);
    }

    public boolean tonTaiTaiKhoan(String taiKhoan) {
        if (taiKhoan == null || taiKhoan.isEmpty()) {
            return false;
        }
        return repository.tonTaiTaiKhoan(taiKhoan);
    }

    public NhanVien dangNhap(String taiKhoan, String matKhau) {
        return repository.dangNhap(taiKhoan, matKhau);
    }
}
