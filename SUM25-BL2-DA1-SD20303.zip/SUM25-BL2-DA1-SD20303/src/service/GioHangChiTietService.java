/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.GioHangChiTiet;
import repository.GioHangChiTietRepository;

/**
 *
 * @author VIET DUC
 */
public class GioHangChiTietService {

    private GioHangChiTietRepository repo = new GioHangChiTietRepository();

    public boolean addOrUpdate(GioHangChiTiet chiTiet) {
        return repo.addOrUpdate(chiTiet);
    }

    public GioHangChiTiet getChiTietByGioHangAndBienThe(int gioHangId, int bienTheId) {
        return repo.getChiTietByGioHangAndBienThe(gioHangId, bienTheId);
    }

    public boolean deleteById(int id) {
        return repo.deleteById(id);
    }

    public List<GioHangChiTiet> getAllByGioHangId(int gioHangId) {
        return repo.getAllByGioHangId(gioHangId);
    }

    public boolean updateSoLuong(int gioHangId, int bienTheId, int soLuongMoi) {
        return repo.updateSoLuong(gioHangId, bienTheId, soLuongMoi);
    }

    public boolean deleteByBienThe(int gioHangId, int bienTheId) {
        return repo.deleteByBienThe(gioHangId, bienTheId);
    }

}
