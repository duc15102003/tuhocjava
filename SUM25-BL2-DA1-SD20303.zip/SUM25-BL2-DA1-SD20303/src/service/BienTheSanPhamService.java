/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.BienTheSanPham;
import repository.BienTheSanPhamRepository;

/**
 *
 * @author VIET DUC
 */
public class BienTheSanPhamService {

    private BienTheSanPhamRepository repository = new BienTheSanPhamRepository();

    public boolean themBienTheSanPham(BienTheSanPham bts) {
        return repository.themBienTheSanPham(bts);
    }

    public boolean suaBienTheSanPhamTheoKey(int oldSanPhamId, int oldMauSacId, int oldKichThuocId, BienTheSanPham newBts) {
        return repository.suaBienTheSanPhamTheoKey(oldSanPhamId, oldMauSacId, oldKichThuocId, newBts);
    }

    public boolean xoaBienTheSanPhamTheoKey(int sanPhamId, int mauSacId, int kichThuocId) {
        return repository.xoaBienTheSanPhamTheoKey(sanPhamId, mauSacId, kichThuocId);
    }

    public List<BienTheSanPham> getAllBienTheSanPham() {
        return repository.getAllBienTheSanPham();
    }

    public BienTheSanPham findBySanPhamMauSize(int sanPhamId, int mauSacId, int kichThuocId) {
        return repository.findBySanPhamMauSize(sanPhamId, mauSacId, kichThuocId);
    }

    public boolean capNhatSoLuongSauKhiBan(int bienTheId, int soLuongTru) {
        return repository.capNhatSoLuongSauKhiBan(bienTheId, soLuongTru);
    }

    public int getSoLuongTonTheoBienThe(int bienTheId) {
        return repository.getSoLuongTonTheoBienThe(bienTheId);
    }

    public BienTheSanPham getBienTheTheoId(int id) {
        return repository.getBienTheTheoId(id);
    }
}
