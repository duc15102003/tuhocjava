/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.HoaDonChiTiet;
import repository.HoaDonChiTietRepository;

/**
 *
 * @author VIET DUC
 */
public class HoaDonChiTietService {

    private HoaDonChiTietRepository repo = new HoaDonChiTietRepository();

    public boolean themChiTiet(HoaDonChiTiet ct) {
        return repo.themChiTietHoaDon(ct);
    }

    public List<HoaDonChiTiet> getByMaHD(int maHD) {
        return repo.getByMaHD(maHD);
    }

    public int getTongSoLuongByMaHD(int maHD) {
        return repo.getTongSoLuongByMaHD(maHD);
    }

    public boolean capNhatChiTiet(HoaDonChiTiet ct) {
        return repo.updateChiTietHoaDon(ct);
    }

    public boolean xoaChiTiet(int id) {
        return repo.xoaChiTietHoaDon(id);
    }
}
