/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import models.SanPham;
import repository.SanPhamRepository;

/**
 *
 * @author VIET DUC
 */
public class SanPhamService {

  private final SanPhamRepository sanPhamRepo = new SanPhamRepository();

    public SanPham themSanPham(SanPham sp) {
        try {
            return sanPhamRepo.themSanPham(sp);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }



    public List<Object[]> layDanhSachSanPhamFull() {
        return sanPhamRepo.layDanhSachSanPhamFull();
    }

    public boolean suaSanPham(SanPham sp) {
        return sanPhamRepo.suaSanPham(sp);
    }

    public boolean xoaSanPham(int id) {
        return sanPhamRepo.xoaSanPham(id);
    }
}


