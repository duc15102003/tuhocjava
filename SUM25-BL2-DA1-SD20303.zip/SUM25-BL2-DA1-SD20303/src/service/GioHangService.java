/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import models.GioHang;
import repository.GioHangRepository;
/**
 *
 * @author VIET DUC
 */
public class GioHangService {
    private GioHangRepository repo = new GioHangRepository();

    public int taoGioHangMoi(String maNV) {
        return repo.createGioHang(maNV);
    }

    public GioHang layGioHangHienTai(String maNV) {
        return repo.getGioHangMoiNhatTheoMaNV(maNV);
    }

    public boolean xoaGioHang(int id) {
        return repo.deleteGioHang(id);
    }
}
