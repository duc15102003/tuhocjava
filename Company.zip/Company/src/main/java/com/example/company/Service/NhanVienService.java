package com.example.company.Service;

import com.example.company.ExceptionHandler.BadRequestException;
import com.example.company.dto.NhanVienRequest;
import com.example.company.dto.NhanVienResponse;
import com.example.company.entity.NhanVien;
import com.example.company.entity.PhongBan;
import com.example.company.exception.ResourceNotFoundException;
import com.example.company.repository.NhanVienRepository;
import com.example.company.repository.PhongBanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class NhanVienService {
    @Autowired
    private NhanVienRepository nhanVienRepository;
    @Autowired
    private PhongBanRepository phongBanRepository;


    // convert từ request DTO -> entity
    public NhanVien convertToEntity(NhanVienRequest nhanVien) {
        NhanVien nv = new NhanVien();
        nv.setName(nhanVien.getName());
        nv.setEmail(nhanVien.getEmail());
        nv.setBirthday(nhanVien.getBirthday());
        PhongBan pb = phongBanRepository.findById(nhanVien.getPhongBanId())
                .orElseThrow(() -> new RuntimeException("Phòng ban không tồn tại"));
        nv.setPhongBan(pb);
        return nv;
    }
    // convert từ entity -> Response DTO
    public NhanVienResponse convertToResponse(NhanVien nhanVien) {
        NhanVienResponse nv = new NhanVienResponse();
        nv.setId(nhanVien.getId());
        nv.setName(nhanVien.getName());
        nv.setEmail(nhanVien.getEmail());
        nv.setBirthday(nhanVien.getBirthday());
        nv.setPhongBan(nhanVien.getPhongBan());
        return nv;
    }
    // save nhan vien
    public NhanVienResponse save(NhanVienRequest nhanVien) {
        NhanVien nv = convertToEntity(nhanVien);
        nv = nhanVienRepository.save(nv);
        return convertToResponse(nv);
    }

    public NhanVienResponse checkBirthday(LocalDate birthday) {
        if (birthday.isAfter(LocalDate.now())) {
            throw new BadRequestException("Ngày sinh không được nằm trong tương lai.");
        }

        Optional<NhanVien> optionalNhanVien = nhanVienRepository.findByBirthday(birthday);

        NhanVien nhanVien = optionalNhanVien.orElseThrow(
                () -> new ResourceNotFoundException("Không có nhân viên nào sinh ngày: " + birthday)
        );

        // Chuyển từ entity -> response
        return convertToResponse(nhanVien);
    }
    public NhanVienResponse update(NhanVienRequest nhanVien, Long id) {
        NhanVien existingNhanVien = nhanVienRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Nhân viên không tồn tại"));

        // Validate: tên không được để trống
        if (nhanVien.getName() == null || nhanVien.getName().trim().isEmpty()) {
            throw new RuntimeException("Tên không được để trống");
        }

        // Validate: email không được để trống
        if (nhanVien.getEmail() == null || nhanVien.getEmail().trim().isEmpty()) {
            throw new RuntimeException("Email không được để trống");
        }

        // Validate: định dạng email (dùng regex đơn giản)
        if (!nhanVien.getEmail().matches("^[\\w.-]+@[\\w.-]+\\.\\w+$")) {
            throw new RuntimeException("Email không hợp lệ");
        }

        // Validate ngày sinh
        if (nhanVien.getBirthday().isAfter(LocalDate.now())) {
            throw new BadRequestException("Ngày sinh không được nằm trong tương lai.");
        }

        List<NhanVien> nhanVienWithSameEmail = nhanVienRepository.findByEmail(nhanVien.getEmail());

        boolean emailDaTonTai = nhanVienWithSameEmail.stream()
                .anyMatch(nv -> !nv.getId().equals(id)); // loại trừ người đang cập nhật

        if (emailDaTonTai) {
            throw new RuntimeException("Email đã được sử dụng bởi nhân viên khác");
        }

        // Cập nhật thông tin
        existingNhanVien.setName(nhanVien.getName());
        existingNhanVien.setEmail(nhanVien.getEmail());
        existingNhanVien.setBirthday(nhanVien.getBirthday());

        PhongBan pb = phongBanRepository.findById(nhanVien.getPhongBanId())
                .orElseThrow(() -> new RuntimeException("Phòng ban không tồn tại"));
        existingNhanVien.setPhongBan(pb);

        existingNhanVien = nhanVienRepository.save(existingNhanVien);
        return convertToResponse(existingNhanVien);
    }
    public void deleteNhanVien(Long id) {
        nhanVienRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên"));
        nhanVienRepository.deleteById(id);
    }

    public List<NhanVienResponse> findBirthdayRange(LocalDate start, LocalDate end) {
        // Kiểm tra ngày sinh không được nằm trong tương lai
        if (start.isAfter(LocalDate.now()) && end.isAfter(LocalDate.now())) {
            throw new BadRequestException("Ngày sinh không được nằm trong tương lai.");
        }

        // Lấy danh sách nhân viên sinh trong khoảng ngày
        List<NhanVien> nhanVienList = nhanVienRepository.findAllByNgaySinhBetween(start, end);

        // Kiểm tra nếu không có nhân viên nào thỏa mãn điều kiện
        if (nhanVienList.isEmpty()) {
            throw new ResourceNotFoundException("Không có nhân viên nào sinh trong khoảng từ " + start + " đến " + end);
        }

        // Chuyển đổi tất cả nhân viên trong danh sách thành Response
        return convertToResponse(nhanVienList);
    }
    private List<NhanVienResponse> convertToResponse(List<NhanVien> nhanVienList) {
        return nhanVienList.stream()
                .map(nv -> new NhanVienResponse(
                        nv.getId(),
                        nv.getName(),
                        nv.getEmail(),
                        nv.getBirthday(),
                        nv.getPhongBan()
                ))
                .collect(Collectors.toList());
    }
    public List<NhanVien> getAll(){
        return nhanVienRepository.findAll();
    }

}
