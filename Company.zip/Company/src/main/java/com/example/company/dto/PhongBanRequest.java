package com.example.company.dto;

public class PhongBanRequest {
}
