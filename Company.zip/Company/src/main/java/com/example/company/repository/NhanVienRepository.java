package com.example.company.repository;

import com.example.company.dto.NhanVienRequest;
import com.example.company.dto.NhanVienResponse;
import com.example.company.entity.NhanVien;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface NhanVienRepository extends JpaRepository<NhanVien, Long> {


    @Query("select a from NhanVien a where a.birthday = :birthday")
    Optional<NhanVien> findByBirthday(@Param("birthday") LocalDate birthday);

    @Query("select a from NhanVien a where a.birthday BETWEEN :start AND :end")
    List<NhanVien> findAllByNgaySinhBetween(LocalDate start, LocalDate end);

    public List<NhanVien> findByEmail(String email);

    @Query(value = "select '*' from NhanVien a where a.id = :id and a.name = :name")
    Optional<NhanVien> findNhanVienByIdAndName(Long id, String name);

}
