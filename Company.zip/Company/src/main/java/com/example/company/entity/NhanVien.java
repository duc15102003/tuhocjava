package com.example.company.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.*;

import java.time.LocalDate;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
@ToString
@Table(name = "NhanVien")
public class NhanVien {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "name không được để trống")
    private String name;
    @NotBlank(message = "email không được để trống")
    @Email(message = "Email không đúng")
    private String email;
    @NotNull(message = "birthday không được trống")
    @Past(message = "Ngày sinh phải trong quá khứ")
    private LocalDate birthday;
    @ManyToOne
    @JoinColumn(name = "phong_ban_id")
    private PhongBan phongBan;
}
