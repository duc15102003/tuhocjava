package com.example.company.controller;

import com.example.company.exception.ResourceNotFoundException;
import com.example.company.Service.NhanVienService;
import com.example.company.dto.NhanVienRequest;
import com.example.company.dto.NhanVienResponse;
import com.example.company.entity.NhanVien;
import com.example.company.repository.NhanVienRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("nhanVien")
public class NhanVienController {
    @Autowired
    private NhanVienService nhanVienService;

    @GetMapping("/")
    public String test(){
        return "Hello World";
    }
    @PostMapping("/add")
    public ResponseEntity<Map<String, String>> createNhanVien(@Valid @RequestBody NhanVienRequest dto) {
        nhanVienService.save(dto);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Thêm nhân viên thành công");

        return ResponseEntity.ok(response);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<NhanVienResponse> updateNhanVien(
            @PathVariable Long id,
            @Valid @RequestBody NhanVienRequest dto) {

        NhanVienResponse updatedNhanVien = nhanVienService.update(dto, id);
        return ResponseEntity.ok(updatedNhanVien);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        try {
            nhanVienService.deleteNhanVien(id);
            return ResponseEntity.ok("Xóa thành công với id=" +id);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Xóa thất bại: " + e.getMessage() + " với id="+id);
        }
    }

    @GetMapping("/birthday/{start}/{end}")
    public List<NhanVienResponse> findByBirthdayRange(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {

        return nhanVienService.findBirthdayRange(start, end);
    }
    @GetMapping("/list")
    public ResponseEntity<?> findAll() {
        List<NhanVien> danhSach = nhanVienService.getAll();
        if (danhSach.isEmpty()) {
//            throw newNotFoundException("Không có nhân viên nào trong danh sách.");
            throw new ResourceNotFoundException("Không có nhân viên nào trong danh sách.");
        }
        return ResponseEntity.ok(danhSach);
    }
    @GetMapping("/checkbirthday/{birthday}")
    public NhanVienResponse checkBirthday(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate birthday) {
        return nhanVienService.checkBirthday(birthday);
    }
}
