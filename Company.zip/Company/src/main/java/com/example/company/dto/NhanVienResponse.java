package com.example.company.dto;

import com.example.company.entity.PhongBan;
import lombok.*;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
public class NhanVienResponse {
    private Long id;
    private String name;
    private String email;
    private LocalDate birthday;
    private PhongBan phongBan;
}
