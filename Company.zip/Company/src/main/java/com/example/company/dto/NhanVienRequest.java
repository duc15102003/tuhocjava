package com.example.company.dto;

import com.example.company.entity.PhongBan;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.*;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
public class NhanVienRequest {
    @NotBlank(message = "name không được để trống")
    private String name;
    @NotBlank(message = "email không được để trống")
    @Email(message = "Email không đúng")
    private String email;
    @NotNull(message = "Không được trống ngày sinh")
    @Past(message = "birthday phải là ngày trong quá khứ và hiện tại")
    private LocalDate birthday;
    @NotNull(message = "ID phòng ban là bắt buộc")
    private Long phongBanId;
}
