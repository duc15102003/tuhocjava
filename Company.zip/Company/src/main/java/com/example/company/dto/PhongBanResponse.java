package com.example.company.dto;

public class PhongBanResponse {
}
